#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QPushButton>
#include <QGridLayout>
#include "ui_mainwindow.h"
#include <QStackedWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

    ~MainWindow();


private slots:

    void on_lineEdit_editingFinished();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();


    void on_radioButton_3_clicked();

    void on_radioButton_4_clicked();

    void on_radioButton_clicked();

    void on_radioButton_2_clicked();

    void on_pushButton_3_clicked();



    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::MainWindow *ui;
    void on_lineEdit_textEdited(const QString &arg1);
    void cellClicked(int row, int column);
    void cellClicked1(int row, int column);
    void cellClicked2(int row, int column);
    //void cellClicked2(int row, int column);
    QPushButton* board[4][4];
    char currentPlayer;
    bool isGameOver;
    void setUpBoard();
     void computerMove();
    void computerMove2();
    void initializeBoard();
    bool isWin();
    bool isValidMove(int oldRow, int oldCol, int newRow, int newCol);
    int oldRow,oldCol;
    bool isPlayer1;
    bool isPlayer2;
    bool isPlayer3;
    bool isPlayer4;
    int computerOldRow = -1;
    int computerOldCol = -1;
    int row,col;
    void playermove();
    void setFirstPageBackground();
    void setsecondPageBackground();
     bool isImageVisible = false;


};
#endif // MAINWINDOW_H
