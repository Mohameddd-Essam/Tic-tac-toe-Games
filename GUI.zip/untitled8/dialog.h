#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:

    void on_lineEdit_editingFinished();

    void on_pushButton_clicked();




    void on_radioButton_3_clicked();

    void on_radioButton_4_clicked();

    void on_radioButton_clicked();

    void on_radioButton_2_clicked();


    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Dialog *ui;
    void on_lineEdit_textEdited(const QString &arg1);
    void cellClicked(int row, int column);
    void cellClicked1(int row, int column);
    void cellClicked2(int row, int column);
    //void cellClicked2(int row, int column);
    QPushButton* board[3][3][3][3];
    char currentPlayer;
    bool isGameOver;
    void setUpBoard();
    // void computerMove();
    //void computerMove2();
    void initializeBoard();
    bool isWin();
    bool isValidMove(int oldRow, int oldCol, int newRow, int newCol);
    int oldRow,oldCol;
    bool isPlayer1;
    bool isPlayer2;
    bool isPlayer3;
    bool isPlayer4;
    int computerOldRow = -1;
    int computerOldCol = -1;
    int row,col;
    //void playermove();
    int imageHeight;
    int imageWidth;


    int currentMiniRow;
    int currentMiniCol;
    bool isMiniBoardSelected;
    void cellClicked(int row, int column,int x,int y);
    bool isMiniWin(int miniRow, int miniCol);
    void computerMove5();
    int miniRow,miniCol;
    int cellRow,cellCol;
    void cellClickedultimate(int row, int column,int x,int y);
    int moves=0;
    void playermove2();
    char whole[3][3];
    bool wholewin();
    bool isImageVisible = false;





};

#endif // DIALOG_H
