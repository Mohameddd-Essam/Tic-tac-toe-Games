#include "dialog.h"
#include "ui_dialog.h"
#include <QMessageBox>
#include <QToolTip>
#include <QPixmap>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog),
    oldRow(-1),
    oldCol(-1),
    currentMiniRow(-1),
    currentMiniCol(-1)
{

    ui->setupUi(this);
    this->setWindowTitle( "World of Tic Tac Toe");
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, QColor(QColorConstants::Svg::orange));
    this->setPalette(palette);
    this->resize(1300,1000);
    currentPlayer = 'X';

    ui->pushButton->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 16px;"
        "   border: 3px solid black;"
        "   border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "   background-color: magenta;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    ui->pushButton_2->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 16px;"
        "   border: 3px solid black;"
        "   border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "   background-color: magenta;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    ui->pushButton_3->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 16px;"
        "   border: 3px solid black;"
        "   border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "   background-color: magenta;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    isGameOver = false;
    isMiniBoardSelected = false;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            whole[i][j] = ' ';
        }
    }
    setUpBoard();
    connect(ui->pushButton, &QPushButton::clicked, this, &Dialog::on_pushButton_clicked);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::setUpBoard() {
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            QWidget *miniBoardWidget = new QWidget(this);
            QGridLayout *miniGrid = new QGridLayout(miniBoardWidget);
            miniGrid->setSpacing(2);
            miniGrid->setContentsMargins(0, 0, 0, 0);

            for (int x = 0; x < 3; ++x) {
                for (int y = 0; y < 3; ++y) {
                    QPushButton *button = new QPushButton(miniBoardWidget);
                    button->setFixedSize(30, 30);
                    button->setStyleSheet("font-size: 18px;");
                    button->setText("");
                    board[i][j][x][y] = button;
                    button->setStyleSheet(
                        "QPushButton {"
                        "background-color: cyan;"
                        "border: 2px solid black;"
                        "color: black;"
                        "font-size: 20px;"
                        "padding: 5px;"
                        "}"
                        );

                    miniGrid->addWidget(button, x, y);

                    if(isPlayer1&&isPlayer3){

                        connect(button, &QPushButton::clicked, this, [=]() {
                            cellClicked(i, j, x, y);
                        });
                    }
                    else if(isPlayer1&&isPlayer4){

                        connect(button, &QPushButton::clicked, this, [=]() {
                            cellClickedultimate(i, j, x, y);
                        });
                    }
                    else if(isPlayer2&&isPlayer3){
                        connect(button, &QPushButton::clicked, this, [=]() { cellClickedultimate(i, j, x, y); });

                    }
                }
            }
            ui->gridLayout->addWidget(miniBoardWidget, i, j);
        }
    }
}
void Dialog::on_pushButton_clicked() {
    QString playerX = ui->lineEdit->text();
    QString playerO = ui->lineEdit_2->text();
    isPlayer1=ui->radioButton->isChecked();
    isPlayer2=ui->radioButton_2->isChecked();
    isPlayer3=ui->radioButton_3->isChecked();
    isPlayer4=ui->radioButton_4->isChecked();

    if (playerX.isEmpty() || playerO.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please enter names for both players.");
        return;
    }
    setUpBoard();
    QMessageBox::information(this, "Game Info", "Start play");
    currentPlayer = 'X';
    isGameOver = false;
    if(isPlayer2&&isPlayer4){
        playermove2();
    }
    else if(isPlayer2&&isPlayer3){
        computerMove5();
    }
}
void Dialog::playermove2() {
    while (!isGameOver) {
        computerMove5();
        if (isGameOver) break;

        computerMove5();
        if (isGameOver) break;
    }
}
void Dialog::cellClicked(int miniRow, int miniCol, int cellRow, int cellCol) {
    if (isGameOver) return;

    if (!isMiniBoardSelected) {
        currentMiniRow = miniRow;
        currentMiniCol = miniCol;
        isMiniBoardSelected = true;
    }

    if (miniRow != currentMiniRow || miniCol != currentMiniCol) {
        QMessageBox::warning(this, "Invalid Move", "You must play in the current selected board!");
        return;
    }

    if (!board[currentMiniRow][currentMiniCol][cellRow][cellCol]->text().isEmpty()) {
        QMessageBox::warning(this, "Invalid Move", "Cell is already occupied!");
        return;
    }
    board[currentMiniRow][currentMiniCol][cellRow][cellCol]->setText(QString(currentPlayer));

    if (isMiniWin(miniRow, miniCol)) {
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();;
        QMessageBox::information(this, "Mini Board Won", QString("%1 wins board (%2, %3)").arg(winnerName).arg(miniRow).arg(miniCol));
        whole[currentMiniRow][currentMiniCol]=currentPlayer;
        for (int k = 0; k < 3; k++) {
            for (int m = 0; m < 3; m++) {
                board[currentMiniRow][currentMiniCol][k][m]->setText(QString(currentPlayer));
                board[currentMiniRow][currentMiniCol][k][m]->setEnabled(false);
            }
        }
        isMiniBoardSelected = false;
        moves=0;
    }
    if (wholewin()) {
        isGameOver = true;
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();;
        QMessageBox::information(this, "Whole Board", QString("%1 wins the whole board!").arg(winnerName));
        return;
    }
    else if(moves==9&&!isMiniWin(miniRow, miniCol)) {
        QMessageBox::information(this, "Draw","Draw");
        isMiniBoardSelected = false;
        moves=0;
    }

    moves++;
    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
}
bool Dialog::wholewin() {
    for (int i = 0; i < 3; ++i) {
        if (whole[i][0] == whole[i][1] &&
            whole[i][1] == whole[i][2] &&
            whole[i][0] != ' ') {
            return true;
        }
    }

    for (int j = 0; j < 3; ++j) {
        if (whole[0][j] == whole[1][j] &&
            whole[1][j] == whole[2][j] &&
            whole[0][j] != ' ') {
            return true;
        }
    }

    if (whole[0][0] == whole[1][1] &&
        whole[1][1] == whole[2][2] &&
        whole[0][0] != ' ') {
        return true;
    }

    if (whole[0][2] == whole[1][1] &&
        whole[1][1] == whole[2][0] &&
        whole[0][2] != ' ') {
        return true;
    }

    return false;
}



bool Dialog::isMiniWin(int miniRow, int miniCol) {
    for (int i = 0; i < 3; ++i) {
        if (board[miniRow][miniCol][i][0]->text() == board[miniRow][miniCol][i][1]->text() &&
            board[miniRow][miniCol][i][1]->text() == board[miniRow][miniCol][i][2]->text() &&
            !board[miniRow][miniCol][i][0]->text().isEmpty()) {
            return true;
        }
    }

    for (int j = 0; j < 3; ++j) {
        if (board[miniRow][miniCol][0][j]->text() == board[miniRow][miniCol][1][j]->text() &&
            board[miniRow][miniCol][1][j]->text() == board[miniRow][miniCol][2][j]->text() &&
            !board[miniRow][miniCol][0][j]->text().isEmpty()) {
            return true;
        }
    }

    if (board[miniRow][miniCol][0][0]->text() == board[miniRow][miniCol][1][1]->text() &&
        board[miniRow][miniCol][1][1]->text() == board[miniRow][miniCol][2][2]->text() &&
        !board[miniRow][miniCol][0][0]->text().isEmpty()) {
        return true;
    }

    if (board[miniRow][miniCol][0][2]->text() == board[miniRow][miniCol][1][1]->text() &&
        board[miniRow][miniCol][1][1]->text() == board[miniRow][miniCol][2][0]->text() &&
        !board[miniRow][miniCol][0][2]->text().isEmpty()) {
        return true;
    }

    return false;
}
/////////////////////////////////////

///////////////////////////////////
void Dialog::cellClickedultimate(int miniRow, int miniCol, int cellRow, int cellCol) {
    if (isGameOver) return;

    if (!isMiniBoardSelected) {
        currentMiniRow = miniRow;
        currentMiniCol = miniCol;
        isMiniBoardSelected = true;
    }

    if (miniRow != currentMiniRow || miniCol != currentMiniCol) {
        QMessageBox::warning(this, "Invalid Move", "You must play in the current selected board!");
        return;
    }

    if (!board[currentMiniRow][currentMiniCol][cellRow][cellCol]->text().isEmpty()) {
        QMessageBox::warning(this, "Invalid Move", "Cell is already occupied!");
        return;
    }
    board[currentMiniRow][currentMiniCol][cellRow][cellCol]->setText(QString(currentPlayer));

    if (isMiniWin(miniRow, miniCol)) {
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();;
        QMessageBox::information(this, "Mini Board Won", QString("%1 wins board (%2, %3)").arg(winnerName).arg(miniRow).arg(miniCol));
        whole[currentMiniRow][currentMiniCol]=currentPlayer;
        for (int k1 = 0; k1 < 3; k1++) {
            for (int m1 = 0; m1 < 3; m1++) {
                board[currentMiniRow][currentMiniCol][k1][m1]->setText(QString(currentPlayer));
                board[currentMiniRow][currentMiniCol][k1][m1]->setEnabled(false);
            }
        }
        isMiniBoardSelected = false;
        moves=0;
    }
    if (wholewin()) {
        isGameOver = true;
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();;
        QMessageBox::information(this, "Whole Board", QString("%1 wins the whole board!").arg(winnerName));
        return;
    }
    else if(moves==9&&!isMiniWin(miniRow, miniCol)) {
        QMessageBox::information(this, "Draw","Draw");
        isMiniBoardSelected = false;
        moves=0;
    }

    moves++;
    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    computerMove5();
}

/////////////////////////////////
void Dialog::computerMove5() {
    if (isGameOver) {
        return;
    }

    if (!isMiniBoardSelected) {
        currentMiniRow = rand() % 3;
        currentMiniCol = rand() % 3;
        isMiniBoardSelected = true;
    }

    miniRow = currentMiniRow;
    miniCol = currentMiniCol;
    do {
        cellRow = rand() % 3;
        cellCol = rand() % 3;
    } while (!board[miniRow][miniCol][cellRow][cellCol]->text().isEmpty());

    board[miniRow][miniCol][cellRow][cellCol]->setText(QString(currentPlayer));

    if (isMiniWin(miniRow, miniCol)) {
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();
        QMessageBox::information(this, "Mini Board Won", QString("%1 wins board (%2, %3)").arg(winnerName).arg(miniRow).arg(miniCol));
        whole[currentMiniRow][currentMiniCol]=currentPlayer;
        for (int k2 = 0; k2 < 3; k2++) {
            for (int m2 = 0; m2 < 3; m2++) {
                board[currentMiniRow][currentMiniCol][k2][m2]->setText(QString(currentPlayer));
                board[currentMiniRow][currentMiniCol][k2][m2]->setEnabled(false);
            }
        }
        isMiniBoardSelected = false;
        moves=0;
    }
    if (wholewin()) {
        isGameOver = true;
        QString winnerName = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();;
        QMessageBox::information(this, "Whole Board", QString("%1 wins the whole board!").arg(winnerName));
        return;
    }
    else if(moves==9&&!isMiniWin(miniRow, miniCol)) {
        QMessageBox::information(this, "Draw","Draw");
        isMiniBoardSelected = false;
        moves=0;
    }

    moves++;

    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
}

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
void Dialog::on_lineEdit_editingFinished() {
    QString text = ui->lineEdit->text();
}

void Dialog::on_lineEdit_textEdited(const QString &text) {
    qDebug() << "Text edited: " << text;
}



void Dialog::on_radioButton_3_clicked()
{
    isPlayer3 = true;
}


void Dialog::on_radioButton_4_clicked()
{
    isPlayer4 = true;
}


void Dialog::on_radioButton_clicked()
{
    isPlayer1 = true;
}


void Dialog::on_radioButton_2_clicked()
{
    isPlayer2 = true;

}


void Dialog::on_pushButton_2_clicked()
{
    QLabel *label_3 = this->findChild<QLabel*>("label_3");

    if (label_3) {
        if (!isImageVisible) {
            QPixmap image("C:/Users/DELL/Downloads/Mooo.jpg");
            label_3->setPixmap(image.scaled(label_3->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            label_3->setToolTip("Hint");
            label_3->show();
        } else {
            label_3->hide();
        }

        isImageVisible = !isImageVisible;
    }
}



void Dialog::on_pushButton_3_clicked()
{
    currentPlayer = 'X';
    isGameOver = false;
    isMiniBoardSelected = false;
    moves = 0;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            whole[i][j] = ' ';
            for (int x = 0; x < 3; ++x) {
                for (int y = 0; y < 3; ++y) {
                    board[i][j][x][y]->setText("");
                    board[i][j][x][y]->setEnabled(true);
                }
            }
        }
    }

    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->radioButton->setChecked(false);
    ui->radioButton_2->setChecked(false);
    ui->radioButton_3->setChecked(false);
    ui->radioButton_4->setChecked(false);

    QLabel *label_3 = this->findChild<QLabel*>("label_3");
    if (label_3) {
        label_3->hide();
    }

    isImageVisible = false;
    QMessageBox::information(this, "Game Reset", "The game has been reset.");
}

