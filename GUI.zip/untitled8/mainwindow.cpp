#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QToolTip>
#include <QPixmap>
#include<QStackedWidget>
#include "dialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    oldRow(-1),
    oldCol(-1)
{
    ui->setupUi(this);
    currentPlayer = 'X';
    this->setWindowTitle( "World of Tic Tac Toe");
    isGameOver = false;
    ui->pushButton_6->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 14px;"
        "   border: 2px solid black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    ui->pushButton_7->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 14px;"
        "   border: 2px solid black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    setFirstPageBackground();
    setsecondPageBackground();

    setUpBoard();

    connect(ui->pushButton, &QPushButton::clicked, this, &MainWindow::on_pushButton_clicked);

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::setFirstPageBackground()
{
    QWidget *firstPage = ui->stackedWidget->widget(0);
    firstPage->resize(800, 600);
    QPixmap backgroundImage("C:/Users/DELL/Downloads/herO (2).jpg");
    QPixmap scaledImage = backgroundImage.scaled(firstPage->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(scaledImage));
    firstPage->setPalette(palette);
    firstPage->setAutoFillBackground(true);
    ui->pushButton_3->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 14px;"
        "   border: 2px solid black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    ui->pushButton_4->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 14px;"
        "   border: 2px solid black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );

}
void MainWindow::setUpBoard() {
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            QPushButton *button = new QPushButton(this);
            button->setFixedSize(70, 70);
            button->setStyleSheet("font-size: 24px;");
            button->setText("");
            board[i][j] = button;
            button->setStyleSheet(
                "QPushButton {"
                "background-color: red;"
                "border: 2px solid black;"
                "color: black;"
                "font-size: 30px;"
                "padding: 5px;"
                "}"
                );

            ui->gridLayout->addWidget(button, i, j);
            if(isPlayer1&&isPlayer3){
                connect(button, &QPushButton::clicked, this, [=]() { cellClicked(i, j); });
            }
            else if(isPlayer1&&isPlayer4){
                connect(button, &QPushButton::clicked, this, [=]() { cellClicked1(i, j); });
            }
            else if(isPlayer2&&isPlayer3){
                connect(button, &QPushButton::clicked, this, [=]() { cellClicked2(i, j); });
            }

        }
    }
}

void MainWindow::initializeBoard() {
    board[0][0]->setText("O");
    board[0][1]->setText("X");
    board[0][2]->setText("O");
    board[0][3]->setText("X");

    board[3][0]->setText("X");
    board[3][1]->setText("O");
    board[3][2]->setText("X");
    board[3][3]->setText("O");
}
void MainWindow::setsecondPageBackground()
{
    QWidget *firstPage = ui->stackedWidget->widget(1);

    QPalette palette;
    palette.setColor(QPalette::Window, QColor(155, 216, 230));
    firstPage->setPalette(palette);
    firstPage->setAutoFillBackground(true);

    ui->pushButton->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 18px;"
        "   border: 2px Dotted black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
    ui->pushButton_2->setStyleSheet(
        "QPushButton {"
        "   background-color: lightblue;"
        "   color: black;"
        "   font-size: 14px;"
        "   border: 2px solid black;"
        "   border-radius: 8px;"
        "}"
        "QPushButton:hover {"
        "   background-color: blue;"
        "}"
        "QPushButton:pressed {"
        "   background-color: darkblue;"
        "}"
        );
}
void MainWindow::on_pushButton_clicked() {
    QString playerX = ui->lineEdit->text();
    QString playerO = ui->lineEdit_2->text();
    isPlayer1=ui->radioButton->isChecked();
    isPlayer2=ui->radioButton_2->isChecked();
    isPlayer3=ui->radioButton_3->isChecked();
    isPlayer4=ui->radioButton_4->isChecked();

    if (playerX.isEmpty() || playerO.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please enter names for both players.");
        return;
    }
    setUpBoard();
    initializeBoard();
    currentPlayer = 'X';
    isGameOver = false;
    if(isPlayer2&&isPlayer3){
        computerMove2();
    }
    else if(isPlayer2&&isPlayer4){
        playermove();
    }
}

bool MainWindow::isWin() {
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 2; ++j) {
            if (board[i][j]->text() == board[i][j+1]->text() &&
                board[i][j+1]->text() == board[i][j+2]->text() &&
                !board[i][j]->text().isEmpty()) {
                return true;
            }
        }
    }

    for (int j = 0; j < 4; ++j) {
        for (int i = 0; i < 2; ++i) {
            if (board[i][j]->text() == board[i+1][j]->text() &&
                board[i+1][j]->text() == board[i+2][j]->text() &&
                !board[i][j]->text().isEmpty()) {
                return true;
            }
        }
    }

    for (int i = 0; i < 2; ++i) {
        if (board[i][i]->text() == board[i+1][i+1]->text() &&
            board[i+1][i+1]->text() == board[i+2][i+2]->text() &&
            !board[i][i]->text().isEmpty()) {
            return true;
        }
    }

    for (int i = 0; i < 2; ++i) {
        if (board[i][3-i]->text() == board[i+1][2-i]->text() &&
            board[i+1][2-i]->text() == board[i+2][1-i]->text() &&
            !board[i][3-i]->text().isEmpty()) {
            return true;
        }
    }

    for (int i = 0; i < 2; ++i) {
        for (int j = 0; j < 2; ++j) {
            if (board[i][j]->text() == board[i+1][j+1]->text() &&
                board[i+1][j+1]->text() == board[i+2][j+2]->text() &&
                !board[i][j]->text().isEmpty()) {
                return true;
            }
            if (board[i][3-j]->text() == board[i+1][2-j]->text() &&
                board[i+1][2-j]->text() == board[i+2][1-j]->text() &&
                !board[i][3-j]->text().isEmpty()) {
                return true;
            }
        }
    }

    return false;
}




bool MainWindow::isValidMove(int oldRow, int oldCol, int newRow, int newCol) {
    if ((abs(oldRow - newRow) == 1 && oldCol == newCol) || (abs(oldCol - newCol) == 1 && oldRow == newRow)) {
        return true;
    }
    return false;
}

void MainWindow::cellClicked(int row, int col) {
    if (isGameOver) {
        return;
    }

    if (oldRow == -1 && oldCol == -1) {
        if (board[row][col]->text() == QString(currentPlayer)) {
            oldRow = row;
            oldCol = col;
            QToolTip::showText(QCursor::pos(), "Now select a valid cell to move to.");
        } else {
            QMessageBox::warning(this, "Invalid Selection", "Please select a cell containing your marker.");
        }
    } else {
        if (isValidMove(oldRow, oldCol, row, col) && board[row][col]->text().isEmpty()) {
            board[row][col]->setText(QString(currentPlayer));
            board[oldRow][oldCol]->setText("");

            if (isWin()) {
                QString winner = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();
                QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(winner));
                isGameOver = true;
                for (int i = 0; i < 4; ++i) {
                    for (int j = 0; j < 4; ++j) {
                        board[i][j]->setText("");
                    }
                }
                ui->lineEdit->clear();
                ui->lineEdit_2->clear();
                return;
            }
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            oldRow = -1;
            oldCol = -1;

        } else {
            QMessageBox::warning(this, "Invalid Move", "This move is not valid. Try again.");
            oldRow = -1;
            oldCol = -1;
        }

    }
}
void MainWindow::computerMove() {
    if (isGameOver) {
        return;
    }

    while (oldRow == -1 && oldCol == -1) {
        int tempRow = rand() % 4;
        int tempCol = rand() % 4;
        if (board[tempRow][tempCol]->text() == QString(currentPlayer)) {
            oldRow = tempRow;
            oldCol = tempCol;
            break;
        }
    }
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            if (isValidMove(oldRow, oldCol, i, j) && board[i][j]->text().isEmpty()) {
                board[i][j]->setText(QString(currentPlayer));
                board[oldRow][oldCol]->setText("");


                if (isWin()) {
                    QMessageBox::information(this, "Game Over", "Computer wins!");
                    isGameOver = true;
                    for (int i = 0; i < 4; ++i) {
                        for (int j = 0; j < 4; ++j) {
                            board[i][j]->setText("");
                        }
                    }
                    currentPlayer = 'X';
                    isGameOver = false;
                    oldRow = -1;
                    oldCol = -1;
                    ui->lineEdit->clear();
                    ui->lineEdit_2->clear();

                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                oldRow = -1;
                oldCol = -1;
                return;
            }
        }
    }
    oldRow = -1;
    oldCol = -1;
}



////////////////////////////////
void MainWindow::cellClicked1(int row, int col) {
    if (isGameOver) {
        return;
    }

    if (oldRow == -1 && oldCol == -1) {
        if (board[row][col]->text() == QString(currentPlayer)) {
            oldRow = row;
            oldCol = col;
            QToolTip::showText(QCursor::pos(), "Now select a valid cell to move to.");
        } else {
            QMessageBox::warning(this, "Invalid Selection", "Please select a cell containing your marker.");
        }
    } else {
        if (isValidMove(oldRow, oldCol, row, col) && board[row][col]->text().isEmpty()) {
            board[row][col]->setText(QString(currentPlayer));
            board[oldRow][oldCol]->setText("");

            if (isWin()) {
                QString winner = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();
                QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(winner));
                isGameOver = true;
                for (int i = 0; i < 4; ++i) {
                    for (int j = 0; j < 4; ++j) {
                        board[i][j]->setText("");
                    }
                }
                ui->lineEdit->clear();
                ui->lineEdit_2->clear();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            oldRow = -1;
            oldCol = -1;
            computerMove();


        } else {
            QMessageBox::warning(this, "Invalid Move", "This move is not valid. Try again.");
            oldRow = -1;
            oldCol = -1;
        }
    }
}
//////////////////////////
void MainWindow::cellClicked2(int row, int col) {
    if (isGameOver) {
        return;
    }


    if (oldRow == -1 && oldCol == -1) {
        if (board[row][col]->text() == QString(currentPlayer)) {
            oldRow = row;
            oldCol = col;
            QToolTip::showText(QCursor::pos(), "Now select a valid cell to move to.");
        } else {
            QMessageBox::warning(this, "Invalid Selection", "Please select a cell containing your marker.");
        }
    } else {
        if (isValidMove(oldRow, oldCol, row, col) && board[row][col]->text().isEmpty()) {
            board[row][col]->setText(QString(currentPlayer));
            board[oldRow][oldCol]->setText("");

            if (isWin()) {
                QString winner = (currentPlayer == 'X') ? ui->lineEdit->text() : ui->lineEdit_2->text();
                QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(winner));
                isGameOver = true;
                for (int i = 0; i < 4; ++i) {
                    for (int j = 0; j < 4; ++j) {
                        board[i][j]->setText("");
                    }
                }
                ui->lineEdit->clear();
                ui->lineEdit_2->clear();
                return;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            oldRow = -1;
            oldCol = -1;
            computerMove2();


        } else {
            QMessageBox::warning(this, "Invalid Move", "This move is not valid. Try again.");
            oldRow = -1;
            oldCol = -1;
        }
    }
}
///////////////////////////
void MainWindow::computerMove2() {
    if (isGameOver) {
        return;
    }

    while (oldRow == -1 && oldCol == -1) {
        int tempRow = rand() % 4;
        int tempCol = rand() % 4;
        if (board[tempRow][tempCol]->text() == QString(currentPlayer)) {
            oldRow = tempRow;
            oldCol = tempCol;
            break;
        }
    }
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            if (isValidMove(oldRow, oldCol, i, j) && board[i][j]->text().isEmpty()) {
                board[i][j]->setText(QString(currentPlayer));
                board[oldRow][oldCol]->setText("");

                if (isWin()) {
                    QMessageBox::information(this, "Game Over", "Computer wins!");
                    isGameOver = true;
                    for (int i = 0; i < 4; ++i) {
                        for (int j = 0; j < 4; ++j) {
                            board[i][j]->setText("");
                        }
                    }
                    currentPlayer = 'X';
                    isGameOver = false;
                    oldRow = -1;
                    oldCol = -1;
                    ui->lineEdit->clear();
                    ui->lineEdit_2->clear();

                }

                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                oldRow = -1;
                oldCol = -1;
                return;
            }
        }
    }


    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    oldRow = -1;
    oldCol = -1;
}

void MainWindow::on_lineEdit_editingFinished() {
    QString text = ui->lineEdit->text();
}

void MainWindow::on_lineEdit_textEdited(const QString &text) {
    qDebug() << "Text edited: " << text;
}

void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirm Reset", "Are you sure you want to reset the game?",
                                  QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                board[i][j]->setText("");
            }
        }
        currentPlayer = 'X';
        isGameOver = false;
        oldRow = -1;
        oldCol = -1;
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
    }
}

void MainWindow::playermove() {
    while (!isGameOver) {
        computerMove2();
        if (isGameOver) break;

        computerMove2();
        if (isGameOver) break;
    }
}
void MainWindow::on_radioButton_3_clicked()
{
    isPlayer3 = true;
}


void MainWindow::on_radioButton_4_clicked()
{
    isPlayer4 = true;
}


void MainWindow::on_radioButton_clicked()
{
    isPlayer1 = true;
}


void MainWindow::on_radioButton_2_clicked()
{
    isPlayer2 = true;

}




void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}






void MainWindow::on_pushButton_4_clicked()
{
    Dialog dialog;
    dialog.exec();
}


void MainWindow::on_pushButton_6_clicked()
{

     ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_7_clicked()
{
    QLabel *label_5 = this->findChild<QLabel*>("label_5");

    if (label_5) {
        if (!isImageVisible) {
            QPixmap image("C:/Users/DELL/Downloads/Moo.jpg");

            // تكبير طول الصورة بنسبة 1.2
            int newWidth = label_5->width();  // عرض QLabel الحالي
            int newHeight = label_5->height()* 1.5;  // تكبير الطول بنسبة 1.2
            label_5->setPixmap(image.scaled(newWidth, newHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation));
            label_5->setToolTip("Hint");
            label_5->show();
        } else {
            label_5->hide();
        }

        isImageVisible = !isImageVisible;
    }
}

